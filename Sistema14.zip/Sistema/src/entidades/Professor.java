package entidades;

public class Professor {
    
    private int cdProfessor;             
    private String diplomaProf;                  
    private String nivelEscProf;                
    private String emailProf;                 
    private String cidadeProf;
    private String bairroProf;
    private String ruaProf;
    private int numeroProf;
    private String cepProf;
    private String nomeProf;
    private String cpfProf;
    private String rgProf;
    private String dataNascProf;
    private String sexoProf;
    private String estadoCivilProf;
    private String racaProf;

    public Professor() {
    }

    public int getCdProfessor() {
        return cdProfessor;
    }

    public void setCdProfessor(int cdProfessor) {
        this.cdProfessor = cdProfessor;
    }

    public String getDiplomaProf() {
        return diplomaProf;
    }

    public void setDiplomaProf(String diplomaProf) {
        this.diplomaProf = diplomaProf;
    }

    public String getNivelEscProf() {
        return nivelEscProf;
    }

    public void setNivelEscProf(String nivelEscProf) {
        this.nivelEscProf = nivelEscProf;
    }

    public String getEmailProf() {
        return emailProf;
    }

    public void setEmailProf(String emailProf) {
        this.emailProf = emailProf;
    }

    public String getCidadeProf() {
        return cidadeProf;
    }

    public void setCidadeProf(String cidadeProf) {
        this.cidadeProf = cidadeProf;
    }

    public String getBairroProf() {
        return bairroProf;
    }

    public void setBairroProf(String bairroProf) {
        this.bairroProf = bairroProf;
    }

    public String getRuaProf() {
        return ruaProf;
    }

    public void setRuaProf(String ruaProf) {
        this.ruaProf = ruaProf;
    }

    public int getNumeroProf() {
        return numeroProf;
    }

    public void setNumeroProf(int numeroProf) {
        this.numeroProf = numeroProf;
    }

    public String getCepProf() {
        return cepProf;
    }

    public void setCepProf(String cepProf) {
        this.cepProf = cepProf;
    }

    public String getNomeProf() {
        return nomeProf;
    }

    public void setNomeProf(String nomeProf) {
        this.nomeProf = nomeProf;
    }

    public String getCpfProf() {
        return cpfProf;
    }

    public void setCpfProf(String cpfProf) {
        this.cpfProf = cpfProf;
    }

    public String getRgProf() {
        return rgProf;
    }

    public void setRgProf(String rgProf) {
        this.rgProf = rgProf;
    }

    public String getDataNascProf() {
        return dataNascProf;
    }

    public void setDataNascProf(String dataNascProf) {
        this.dataNascProf = dataNascProf;
    }

    public String getSexoProf() {
        return sexoProf;
    }

    public void setSexoProf(String sexoProf) {
        this.sexoProf = sexoProf;
    }

    public String getEstadoCivilProf() {
        return estadoCivilProf;
    }

    public void setEstadoCivilProf(String estadoCivilProf) {
        this.estadoCivilProf = estadoCivilProf;
    }

    public String getRacaProf() {
        return racaProf;
    }

    public void setRacaProf(String racaProf) {
        this.racaProf = racaProf;
    }

    public void imprimeAtributos(){
        System.out.println("ID: " + cdProfessor);
        System.out.println("Diploma: " + diplomaProf);
        System.out.println("Nível de Escolaridade: " + nivelEscProf);
        System.out.println("Email: " + emailProf);
        System.out.println("Cidade: " + cidadeProf);
        System.out.println("Bairro: " + bairroProf);
        System.out.println("Rua: " + ruaProf);
        System.out.println("Número: " + numeroProf);
        System.out.println("CEP: " + cepProf);
        System.out.println("Nome: " + nomeProf);
        System.out.println("CPF: " + cpfProf);
        System.out.println("RG: " + rgProf);
        System.out.println("Data de Nascimento: " + dataNascProf);
        System.out.println("Sexo: " + sexoProf);
        System.out.println("Estado Civil: " + estadoCivilProf);
        System.out.println("Raça: " + racaProf);
}
}

