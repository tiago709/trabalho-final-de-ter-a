package entidades;

public class ProfessorTurma {
    
    private int cdProfessorTurma;
    private int cdProfessor;
    private int cdTurma;

    public ProfessorTurma() {
    }
    
    public int getCdProfessorTurma() {
        return cdProfessorTurma;
    }

    public void setCdProfessorTurma(int cdProfessorTurma) {
        this.cdProfessorTurma = cdProfessorTurma;
    }

    public int getCdProfessor() {
        return cdProfessor;
    }

    public void setCdProfessor(int cdProfessor) {
        this.cdProfessor = cdProfessor;
    }

    public int getCdTurma() {
        return cdTurma;
    }

    public void setCdTurma(int cdTurma) {
        this.cdTurma = cdTurma;
    }
    
    
    public void imprimeAtributos(){
        System.out.println("Código do professor por turma: " + cdProfessorTurma);
        System.out.println("Código do professor: " + cdProfessor);
        System.out.println("Código da turma: " + cdTurma);
    }
}
