package entidades;

public class Sala {
 
    private int cdSala;        
    private double areaQ;        
    private int capacidade;      
    private String observacaoSala; 
    private String nomeSala;    

    public Sala() {
    }

    public int getCdSala() {
        return cdSala;
    }

    public void setCdSala(int cdSala) {
        this.cdSala = cdSala;
    }

    public double getAreaQ() {
        return areaQ;
    }

    public void setAreaQ(double areaQ) {
        this.areaQ = areaQ;
    }

    public int getCapacidade() {
        return capacidade;
    }

    public void setCapacidade(int capacidade) {
        this.capacidade = capacidade;
    }

    public String getObservacaoSala() {
        return observacaoSala;
    }

    public void setObservacaoSala(String observacaoSala) {
        this.observacaoSala = observacaoSala;
    }

    public String getNomeSala() {
        return nomeSala;
    }

    public void setNomeSala(String nomeSala) {
        this.nomeSala = nomeSala;
    }
    
   
    public void imprimeAtributos() {
        System.out.println("Código da Sala: " + cdSala);
        System.out.println("Área: " + areaQ + " m²");
        System.out.println("Capacidade: " + capacidade + " pessoas");
        System.out.println("Observação: " + observacaoSala);
        System.out.println("Nome da Sala: " + nomeSala);
    }  
}
