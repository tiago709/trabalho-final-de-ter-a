package entidades;

public class Turma {
    
    private int cdTurma;
    private int cdSala;
    private String disciplinaTurma;
    private int cargaHTurma;
    private String salaTurma;

    public Turma() {
    }

    public int getCdTurma() {
        return cdTurma;
    }

    public void setCdTurma(int cdTurma) {
        this.cdTurma = cdTurma;
    }
    
    public int getCdSala() {
        return cdSala;
    }

    public void setCdSala(int cdSala) {
        this.cdSala = cdSala;
    }

    public String getDisciplinaTurma() {
        return disciplinaTurma;
    }

    public void setDisciplinaTurma(String disciplinaTurma) {
        this.disciplinaTurma = disciplinaTurma;
    }

    public int getCargaHTurma() {
        return cargaHTurma;
    }

    public void setCargaHTurma(int cargaHTurma) {
        this.cargaHTurma = cargaHTurma;
    }

    public String getSalaTurma() {
        return salaTurma;
    }

    public void setSalaTurma(String salaTurma) {
        this.salaTurma = salaTurma;
    }

      
     public void imprimeAtributos() {
         System.out.println("Código da sala: " + cdSala);
         System.out.println("Diciplina da sala: " + disciplinaTurma);
         System.out.println("Carga Horaria: " + cargaHTurma);
         System.out.println("Sala: " + salaTurma);
     }

}
