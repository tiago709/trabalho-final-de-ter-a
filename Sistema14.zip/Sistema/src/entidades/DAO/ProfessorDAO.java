package entidades.DAO;

import apoio.ConexaoBD;
import entidades.Professor;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ProfessorDAO {

 ResultSet resultadoQ = null;

    public void salvar(Professor c) throws SQLException {

        String sql = ""
                + "INSERT INTO professor (diplomaProf, nivelEscProf, emailProf, cidadeProf, bairroProf, ruaProf, numeroProf,cepProf, nomeProf, cpfProf, rgProf, dataNascProf, sexoProf, estadoCivilProf, racaProf) VALUES ("
                + "'" + c.getDiplomaProf()+ "',"
                + "'" + c.getNivelEscProf()+ "',"
                + "'" + c.getEmailProf()+ "'," 
                + "'" + c.getCidadeProf()+ "',"
                + "'" + c.getBairroProf()+ "',"
                + "'" + c.getRuaProf()+ "',"
                + "'" + c.getNumeroProf()+ "',"
                + "'" + c.getCepProf()+ "',"
                + "'" + c.getNomeProf()+ "',"
                + "'" + c.getCpfProf()+ "',"
                + "'" + c.getRgProf()+ "',"
                + "'" + c.getDataNascProf()+ "',"  
                + "'" + c.getSexoProf()+ "',"
                + "'" + c.getEstadoCivilProf()+ "',"
                + "'" + c.getRacaProf()+ "' "
                + ")";

        System.out.println("sql: " + sql);
        
        ConexaoBD.executeUpdate(sql);

    }

    public ArrayList<Professor> recuperarTodos() throws SQLException {
        ArrayList<Professor> professores = new ArrayList();

        String sql = ""
                + "SELECT * FROM professor ";

        resultadoQ = ConexaoBD.executeQuery(sql);

        while (resultadoQ.next()) {
            Professor professor = new Professor();

            professor.setBairroProf(resultadoQ.getString("bairroProf"));
            professor.setCdProfessor(resultadoQ.getInt("cdProfessor"));
            professor.setCepProf(resultadoQ.getString ("cepProf"));
            professor.setCidadeProf(resultadoQ.getString("cidadeProf"));
            professor.setCpfProf(resultadoQ.getString("cpfProf"));
            professor.setDataNascProf(resultadoQ.getString("dataNascProf"));
            professor.setDiplomaProf(resultadoQ.getString("diplomaProf"));
            professor.setEmailProf(resultadoQ.getString("emailProf"));
            professor.setEstadoCivilProf(resultadoQ.getString("estadoCivilProf"));
            professor.setNivelEscProf(resultadoQ.getString("nivelEscProf"));
            professor.setNomeProf(resultadoQ.getString("nomeProf"));
            professor.setNumeroProf(resultadoQ.getInt("numeroProf"));
            professor.setRacaProf(resultadoQ.getString("racaProf"));
            professor.setRgProf(resultadoQ.getString("rgProf"));
            professor.setRuaProf(resultadoQ.getString("ruaProf"));
            professor.setSexoProf(resultadoQ.getString("sexoProf"));
            

            professores.add(professor);
        }

        return professores;
    }
    
    public Professor recuperar(int id) throws SQLException {
        Professor professor = null;
        String sql = ""
                + "SELECT * FROM professor WHERE cdProfessor = " + id;

        resultadoQ = ConexaoBD.executeQuery(sql);

        if (resultadoQ.next()) {
            professor = new Professor();

            professor.setBairroProf(resultadoQ.getString("bairroProf"));
            professor.setCdProfessor(resultadoQ.getInt("cdProfessor"));
            professor.setCepProf(resultadoQ.getString ("cepProf"));
            professor.setCidadeProf(resultadoQ.getString("cidadeProf"));
            professor.setCpfProf(resultadoQ.getString("cpfProf"));
            professor.setDataNascProf(resultadoQ.getString("dataNascProf"));
            professor.setDiplomaProf(resultadoQ.getString("diplomaProf"));
            professor.setEmailProf(resultadoQ.getString("emailProf"));
            professor.setEstadoCivilProf(resultadoQ.getString("estadoCivilProf"));
            professor.setNivelEscProf(resultadoQ.getString("nivelEscProf"));
            professor.setNomeProf(resultadoQ.getString("nomeProf"));
            professor.setNumeroProf(resultadoQ.getInt("numeroProf"));
            professor.setRacaProf(resultadoQ.getString("racaProf"));
            professor.setRgProf(resultadoQ.getString("rgProf"));
            professor.setRuaProf(resultadoQ.getString("ruaProf"));
            professor.setSexoProf(resultadoQ.getString("sexoProf"));
            
        }

        return professor;
    }

    public void editar(Professor c) throws SQLException {
        String sql = ""
                + "UPDATE professor "
                + "SET "
                + "diplomaProf = '" + c.getDiplomaProf()+ "',"
                + "nivelEscProf = '" + c.getNivelEscProf()+ "',"
                + "emailProf = '" + c.getEmailProf()+ "',"
                + "cidadeProf = '" + c.getCidadeProf()+ "',"
                + "bairroProf = '" + c.getBairroProf()+ "',"
                + "ruaProf = '" + c.getRuaProf()+ "',"
                + "numeroProf = '" + c.getNumeroProf()+ "',"
                + "cepProf = '" + c.getCepProf()+ "',"
                + "nomeProf = '" + c.getNomeProf()+ "',"
                + "cpfProf = '" + c.getCpfProf()+ "',"
                + "rgProf = '" + c.getRgProf()+ "',"
                + "dataNascProf = '" + c.getDataNascProf()+ "',"
                + "sexoProf = '" + c.getSexoProf()+ "',"
                + "estadoCivilProf = '" + c.getEstadoCivilProf()+ "',"
                + "racaProf = '" + c.getRacaProf()+ "' "
                + "WHERE cdProfessor = " + c.getCdProfessor();

        System.out.println("sql: " + sql);

        ConexaoBD.executeUpdate(sql);
    }

    public void excluir(int id) throws SQLException {
        String sql = ""
                + "DELETE FROM professor WHERE cdProfessor = " + id;

        System.out.println("sql: " + sql);

        ConexaoBD.executeUpdate(sql);
    }
}

