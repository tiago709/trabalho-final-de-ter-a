package entidades.DAO;

import entidades.Turma;
import java.util.ArrayList;
import apoio.ConexaoBD;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TurmaDAO {
 
 ResultSet resultadoQ = null;

    public void salvar(Turma c) throws SQLException {

        String sql = ""
                + "INSERT INTO turma ( disciplinaTurma, cargaHTurma, salaTurma, cdSala ) VALUES ("
                + "'" + c.getDisciplinaTurma()+ "',"
                + "'" + c.getCargaHTurma()+ "',"                
                + "'" + c.getSalaTurma()+ "',"
                + "'" + c.getCdSala()+ "',"
                + ")";
    
        System.out.println("sql: " + sql);
        
        ConexaoBD.executeUpdate(sql);

    }

    public ArrayList<Turma> recuperarTodos() throws SQLException {
        ArrayList<Turma> turmas = new ArrayList();

        String sql = ""
                + "SELECT * FROM turma ";

        resultadoQ = ConexaoBD.executeQuery(sql);

        while (resultadoQ.next()) {
            Turma turma = new Turma();

            turma.setCargaHTurma(resultadoQ.getInt("cargaHTurma"));
            turma.setCdSala(resultadoQ.getInt("cdSala"));
            turma.setCdTurma(resultadoQ.getInt("cdTurma"));
            turma.setDisciplinaTurma(resultadoQ.getString("disciplinaTurma"));
            turma.setSalaTurma(resultadoQ.getString("salaTurma"));
                    
            turmas.add(turma);
        }

        return turmas;
    }

    public Turma recuperar(int id) throws SQLException {
        Turma turma = null;
        String sql = ""
                + "SELECT * FROM turma WHERE cdTurma = " + id;

        resultadoQ = ConexaoBD.executeQuery(sql);

        if (resultadoQ.next()) {
            turma = new Turma();

            turma.setCargaHTurma(resultadoQ.getInt("cargaHTurma"));
            turma.setCdSala(resultadoQ.getInt("cdSala"));
            turma.setCdTurma(resultadoQ.getInt("cdTurma"));
            turma.setDisciplinaTurma(resultadoQ.getString("disciplinaTurma"));
            turma.setSalaTurma(resultadoQ.getString("salaTurma"));
        }

        return turma;
    }

    public void editar(Turma c) throws SQLException {
        String sql = ""
                + "UPDATE turma "
                + "SET "
                + "disciplinaTurma = '" + c.getDisciplinaTurma()+ "',"
                + "cargaHTurma = '" + c.getCargaHTurma()+ "',"
                + "salaTurma = '" + c.getSalaTurma()+ "',"
                + "cdSala = '" + c.getCdSala()+ "' "
                + "WHERE cdTurma= " + c.getCdTurma();

        System.out.println("sql: " + sql);

        ConexaoBD.executeUpdate(sql);
    }

    public void excluir(int id) throws SQLException {
        String sql = ""
                + "DELETE FROM turma WHERE cdTurma = " + id;

        System.out.println("sql: " + sql);

        ConexaoBD.executeUpdate(sql);
    }
}







