package entidades.DAO;

import entidades.Sala;
import java.util.ArrayList;
import apoio.ConexaoBD;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SalaDAO {

 ResultSet resultadoQ = null;

    public void salvar(Sala c) throws SQLException {

        String sql = ""
                + "INSERT INTO sala (areaQ, capacidade, observacao, nomeSala) VALUES ("
                + "'" + c.getAreaQ()+ "',"
                + "'" + c.getCapacidade()+ "',"
                + "'" + c.getObservacaoSala()+ "',"
                + "'" + c.getNomeSala()+ "' "
                + ")";

        System.out.println("sql: " + sql);
        
        ConexaoBD.executeUpdate(sql);

    }

    public ArrayList<Sala> recuperarTodos() throws SQLException {
        ArrayList<Sala> salas = new ArrayList();

        String sql = ""
                + "SELECT * FROM sala ";

        resultadoQ = ConexaoBD.executeQuery(sql);

        while (resultadoQ.next()) {
            Sala sala = new Sala();

            sala.setAreaQ(resultadoQ.getInt("areaQ"));
            sala.setCapacidade(resultadoQ.getInt("capacidade"));
            sala.setCdSala(resultadoQ.getInt("cdSala"));
            sala.setNomeSala(resultadoQ.getString("nomeSala"));
            sala.setObservacaoSala(resultadoQ.getString("observacao"));

            salas.add(sala);
        }

        return salas;
    }

    public Sala recuperar(int id) throws SQLException {
        Sala sala = null;
        String sql = ""
                + "SELECT * FROM sala WHERE cdSala = " + id;

        resultadoQ = ConexaoBD.executeQuery(sql);

        if (resultadoQ.next()) {
            sala = new Sala();

            sala.setAreaQ(resultadoQ.getInt("areaQ"));
            sala.setCapacidade(resultadoQ.getInt("capacidade"));
            sala.setCdSala(resultadoQ.getInt("cdSala"));
            sala.setNomeSala(resultadoQ.getString("nomeSala"));
            sala.setObservacaoSala(resultadoQ.getString("observacao"));
        }

        return sala;
    }

    public void editar(Sala c) throws SQLException {
        String sql = ""
                + "UPDATE sala "
                + "SET "
                + "areaQ = '" + c.getAreaQ()+ "',"
                + "capacidade = '" + c.getCapacidade()+ "',"
                + "observacao = '" + c.getObservacaoSala()+ "',"
                + "nomeSala = '" + c.getNomeSala()+ "' "
                + "WHERE cdSala = " + c.getCdSala();

        System.out.println("sql: " + sql);

        ConexaoBD.executeUpdate(sql);
    }

    public void excluir(int id) throws SQLException {
        String sql = ""
                + "DELETE FROM sala WHERE cdSala = " + id;

        System.out.println("sql: " + sql);

        ConexaoBD.executeUpdate(sql);
    }
}





